// public/javascript/config.js
const API_BASE_URL = "https://media-imt.onrender.com";
// Se estiver testando local, descomente a linha de baixo:
// const API_BASE_URL = "http://localhost:3000";